const axios = require('axios');

module.exports = {
  tokens: "8556737651:AAG_pP4J_4qxx9R5RL6YlQ67sr0_e7oIxkc",  // Masukin Bot token kamu
  owners: "7885097329", // Masukin ID Telegram kamu
  port: "2432", // Masukin Port panel kamu 
  ipvps: "http://jhonaleystore-free.serverprivv.my.id", // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )

  // Bot Appearance & Settings (Move here for easier renaming/encrypted index.js)
  botSettings: {
    botName: "Faiq Crash",
    startImage: 'https://files.catbox.moe/j5k0yy.jpg',
    footerText: "𝐒𝐢𝐗 ☊ 𝐕𝐞𝐫𝐬𝐢𝐨𝐧",
    footerLink: "https://t.me/FaiqOffc",

    // Poll Menu Settings
    pollTitle: '🌜 Pilih Menu yang Diinginkan',
    pollOptions: ['🔑 sᴇᴛᴛɪɴɢs ᴍᴇɴᴜ', '🔧 ᴏᴡɴᴇʀ ᴍᴇɴᴜ', '📊 sᴇssɪᴏɴ sᴛᴀᴛᴜs', '❌ ᴄᴀɴᴄᴇʟ'],

    // Devs / Links buttons
    buttons: [
      { text: 'ϟ', url: 'https://t.me/FaiqOffc' },
      { text: '🍷', url: 'https://t.me/aboutfaiq' }
    ]
  },

  // Dynamic Functions for Messages
  messages: {
    getStartCaption: (username, settings) => {
      // You can edit the HTML/style here
      return `<blockquote><b>${settings.botName}</b></blockquote>\nWelcome, @${username}\n\n<blockquote><a href="${settings.footerLink}">${settings.footerText}</a></blockquote>`;
    }
  }
};